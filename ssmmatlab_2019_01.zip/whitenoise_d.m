% script file to simulate a white noise series with 100 observations
% normally distributed with zero mean and unit variance

y = randn(100,1);
plot(y)