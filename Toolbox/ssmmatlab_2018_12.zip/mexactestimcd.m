function [xvf, str, ferror] = mexactestimcd(y, str, Y, constant)
%
% This function estimates a VARMA model in echelon form with some of its
% parameters possibly restricted to zero followed by a multivariate
% ``differenced'' series. Estimation is performed using the exact maximum
% likelihood method. It is assumed that initial values obtained with the
% three stages of the Hannan-Rissanen or the conditional method are
% available in str.beta3. These initial estimates can be obtained using the
% functions MHANRIS, ESTVARMAXPQRPQR or ESTVARAMXKRO for the
% Hannan-Rissanen method or function MCONESTIM for the conditional method.
% The state space echelon form is:
%
%  alpha_{t+1} = F*alpha_{t} + K*a_{t}
%      y_{t}   = Y_{t}*beta + H*alpha_{t} +a_{t}
%
% The parameters in beta are concentrated out of the likelihood.
%
% The VARMA echelon form is

%  phi(B)*y_{t} = theta(B)a_{t},
%
% where B is the backshift operator, B*y_{t} = y_{t-1}.
%
% Inputs: y      = an (nobs x s) matrix of y-vectors
%       str: a structure containing a preliminary model estimation obtained
%            with functions mhanris, estvaramxpqrPQR or estvarmaxkro.
%         Y: (nobs*s x nbeta) matrix for regression variables other than the mean.
%            (s x nbeta) if it is time invariant;
%  constant: =1 a constant should be included in the model for the
%               differenced series
%             0 no constant in the model for the differenced series
%  Output: xvf: estimated parameters
%          str: a structure containing the estimated VARMAX model.
%       ferror: flag for errors
% The fields of structure str on output are the same as those on input plus
% the following
%         sigma2c: concentrated parameter estimate
%      sigmarexct: estimated covariance matrix of innovations
%                  regression paramters
%               e: stack of white noise residuals
%        phisexct: an (s x s x nlag) array containing the estimated AR
%                  parameters
%      thetasexct: an (s x s x nlag) array containing the estimated MA
%                  parameters
%      gammasexct: an (s x m x nlag) array containing the estimated
%                  exogenous parameters
%       phitvexct: an (s x s x nlag) array containing the p-values of the
%                  estimated AR parameters
%     thetatvexct: an (s x s x nlag) array containing the p-values of the
%                  estimated MA parameters
%     gammatvexct: an (s x m x nlag) array containing the p-values of the
%                  estimated exogenous parameters
%         musexct: an (s x 1) vector containing the estimated constant
%        mutvexct: an (s x 1) vector containing the p-values of the
%                  constant
%       phistexct: same as phiscon but with coefficient matrices
%                  premultiplied by phis(:,:,1)^{-1} (VARMAX model not in
%                  echelon form)
%     thetastexct: same as thetascon but with coefficient matrices
%                  premultiplied by phis(:,:,1)^{-1} (VARMAX model not in
%                  echelon form)
%     gammastexct: same as gammascon but with coefficient matrices
%                  premultiplied by phis(:,:,1)^{-1} (VARMAX model not in
%                  echelon form)
%          Fsexct: an (n x n) matrix containing the estimated F, where n is
%                  the McMillan degree = sum of the Kronecker indices
%          Ksexct: an (n x s) matrix containing the estimated K
%          Bsexct: an (n x m) matrix containing the estimated B
%          Dsexct: an (s x m) matrix containing the estimated D
%          Hsexct: an (s x n) matrix containing the estimated H
%      ferror    = flag for errors
%
% Copyright (c) January 2010 by Victor Gomez
% Ministerio de Hacienda, Direccion Gral. de Presupuestos,
% Subdireccion Gral. de Analisis y P.E.,
% Alberto Alcocer 2, 1-P, D-34, 28046, Madrid, SPAIN.
% Phone : +34-915835439
% E-mail: VGomez@sepg.minhap.es
%
% The author assumes no responsibility for errors or damage resulting from the use
% of this code. Usage of this code in applications and/or alterations of it should
% be referenced. This code may be redistributed if nothing has been added or
% removed and no money is charged. Positive or negative feedback would be appreciated.
%

xvf = [];
ferror = 0;

[ny, my] = size(y); %each row is an observation, each column is a variable

%check stationarity and invertibility.
iar = chkstainv(str.Fs3); %if iar >1, the model is not stationary
if iar > 1
    fprintf(1, 'initial model nonstationary in mexactestimcd, iar = %2d\n', iar);
    str = sta3r(str);
end
ima = chkstainv(str.Fs3-str.Ks3*str.Hs3); %if ima >1, the model is not invertible
if ima > 1
    fprintf(1, 'inital model noninvertible in mexactestimcd, ima = %2d\n', ima);
    str = inv3r(str);
end


%initial parameters
xv = str.beta3'; %polynomial parameters
sigmar = str.sigmar3; %covariance matrix parameters
[R, p] = chol(sigmar);
L = R';
if (p > 0)
    disp('covariance matrix of residuals singular in mexactestimcd')
    ferror = 1;
    return
end
L = L ./ L(1, 1); %sigma(1,1) is concentrated out of the
%likelihood
Lh = vech(L);
xv = [xv(1:end-my), Lh(2:end)'];

%initial unit root paramaters
xvd = str.xvd;
xfd = str.xfd;
xv = [xvd, xv];
xf = xfd;


f = 'exactmedfvcd';
tr = 0;
mvx = 1; %parameters for Levenberg-Marquardt method:
tolf = 1e-4; %f  :   a function to evaluate the vector ff of individual
maxit = 100;
nu0 = .01; %       functions such that ff'*ff is minimized
jac = 1;
prt = 2; %tr :   >0 x is passed from marqdt to f but not passed from f
clear infm
infm = minfm(f, tr, mvx, tolf, maxit, nu0, jac, prt, [], []);
% infm.F='conmedfjac';
%Levenberg-Marquardt method
chb = 0;
[xvf, J, ff, g, iter, conf] = marqdt(infm, xv, y, xf, str, Y, chb, constant);
%this part added 21-2-2011
if (abs(sum(sum(J))) <= 1.d-8)
    error('estimation failed in mexactestimcd')
end
%end of addition
beta = xvf';
chb = 1; %estimate regression variables
[ff, xvft, e, f, str, stx] = exactmedfvcd(xvf, y, xf, str, Y, chb, constant);
hb = stx.hb;
Mb = stx.Mb;
nyd = str.nyd;
sigma2c = e' * e / double(nyd*my); %concentrated parameter estimate
str.sigma2c = sigma2c;
bind = str.bind;
[nbind, mbind] = size(bind); %nbind includes the mean parameters
nparma = nbind - my; %number of parameters in ar and ma parts
L = zeros(my);
l = 0;
betam = [1., xvf(nparma+1:end)];
for i = 1:my
    cont = my - i + 1;
    ind = l + 1:l + cont;
    L(i:end, i) = betam(ind);
    l = l + cont;
end
sigmar = L * L' * sigma2c; %estimated exact covariance matrix of residuals
str.sigmarexct = sigmar;
str.e = e;
% sigma2c,sigmar

%standard errors and t-values
V = -J; % negative derivatives for the regression
res2t = ff + V * beta; % regression
[beta3, tv3] = btval([], [res2t, V]);
str.betaexct = beta;
str.tvexct = tv3;

%use an auxiliary structure to compute the state space and VARMA
%echelon forms corresponding to the exact m.l. estimation
str3 = str;
str3 = param2sse(str3);
%store results
str.phisexct = str3.phis;
str.thetasexct = str3.thetas;
str.gammasexct = str3.gammas;
str.phitvexct = str3.phitv;
str.thetatvexct = str3.thetatv;
str.gammatvexct = str3.gammatv;
str.musexct = hb;
str.mutvexct = hb ./ sqrt(diag(Mb));
str.phistexct = str3.phist;
str.thetastexct = str3.thetast;
str.gammastexct = str3.gammast;
str.Fsexct = str3.Fs;
str.Ksexct = str3.Ks;
str.Bsexct = str3.Bs;
str.Dsexct = str3.Ds;
str.Hsexct = str3.Hs;


% insert estimated parameters in vgam
% vgam=str.vgam;  bind=str.bind;
% vgams3=vgam;  vgamtv3=vgam;
% for i=1:nparma
%  vgams3(bind(i))=beta(i);
%  vgamtv3(bind(i))=tv3(i);
% end
% str.vgams3=vgams3; str.vgamtv3=vgamtv3;
lLh = length(Lh);
lbeta = length(beta);
if lLh > 1
    str.Lh = beta(lbeta-length(Lh)+2:lbeta);
    str.Lhtv3 = tv3(end-length(Lh)+2:end);
end
